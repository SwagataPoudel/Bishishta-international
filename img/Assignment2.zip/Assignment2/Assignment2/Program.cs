﻿using Assignment2;

// task1
Task1 q1 = new Task1();
q1.ShowDetails();

// task2
Task2 q2 = new Task2();
q2.Calculate();

// task3
Task3 q3 = new Task3();
q3.EvenOdd();

// task4
Task4 q4 = new Task4();
q4.Largest();

// task5
Task5 q5 = new Task5();
q5.CheckVoting();

// task6
Task6 q6 = new Task6();
q6.DisplayGrade();

// task7
Task7 q7 = new Task7();
q7.SumNaturalNumbers();

// task8
Task8 q8 = new Task8();
q8.MultiplicationTable();

// task9
Task9 q9 = new Task9();
q9.Factorial();

// task10
Task10 q10 = new Task10();
q10.ReverseNumber();

// task11
Task11 q11 = new Task11();
q11.Fibonacci();