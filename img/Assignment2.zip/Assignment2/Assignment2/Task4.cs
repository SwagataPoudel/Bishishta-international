﻿namespace Assignment2
{
    public class Task4
    {
        public void Largest()
        {
            Console.Write("Enter first number: ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Enter second number: ");
            int b = int.Parse(Console.ReadLine());

            Console.Write("Enter third number: ");
            int c = int.Parse(Console.ReadLine());

            if (a >= b && a >= c)
                Console.WriteLine(a + " is the largest");
            else if (b >= a && b >= c)
                Console.WriteLine(b + " is the largest");
            else
                Console.WriteLine(c + " is the largest");
        }
    }
}
