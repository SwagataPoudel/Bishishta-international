﻿namespace Assignment2
{
    public class Task7
    {
        public void SumNaturalNumbers()
        {
            int sum = 0;
            for (int i = 1; i <= 10; i++)
            {
                sum += i;
            }
            Console.WriteLine("Sum of first 10 natural numbers = " + sum);
        }
    }
}
