﻿namespace Assignment2
{
    public class Task5
    {
        public void CheckVoting()
        {
            Console.Write("Enter your age: ");
            int age = int.Parse(Console.ReadLine());

            if (age >= 18)
                Console.WriteLine("You are eligible to vote.");
            else
                Console.WriteLine("You are not eligible to vote.");
        }
    }
}
