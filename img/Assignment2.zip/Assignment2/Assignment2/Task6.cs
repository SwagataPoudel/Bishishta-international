﻿namespace Assignment2
{
    public class Task6
    {
        public void DisplayGrade()
        {
            Console.Write("Enter your marks: ");
            int marks = int.Parse(Console.ReadLine());

            if (marks >= 80)
                Console.WriteLine("Grade: A");
            else if (marks >= 60)
                Console.WriteLine("Grade: B");
            else if (marks >= 40)
                Console.WriteLine("Grade: C");
            else
                Console.WriteLine("Grade: Fail");
        }
    }
}
