﻿namespace Assignment2
{
    public class Task8
    {
        public void MultiplicationTable()
        {
            Console.Write("Enter a number: ");
            int num = int.Parse(Console.ReadLine());

            int i = 1;
            while (i <= 10)
            {
                Console.WriteLine(num + " x " + i + " = " + (num * i));
                i++;
            }
        }
    }
}
