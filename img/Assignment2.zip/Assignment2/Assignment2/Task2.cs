﻿namespace Assignment2
{
    public class Task2
    {
        public void Calculate()
        {
            Console.Write("Enter first number: ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Enter second number: ");
            double b = double.Parse(Console.ReadLine());

            Console.WriteLine("Sum = " + (a + b));
            Console.WriteLine("Difference = " + (a - b));
            Console.WriteLine("Product = " + (a * b));

            if (b != 0)
                Console.WriteLine("Quotient = " + (a / b));
            else
                Console.WriteLine("Cannot divide by zero");
        }
    }
}
