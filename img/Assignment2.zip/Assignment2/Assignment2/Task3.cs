﻿namespace Assignment2
{
    public class Task3
    {
        public void EvenOdd()
        {
            Console.Write("Enter a number: ");
            int num = int.Parse(Console.ReadLine());

            if (num % 2 == 0)
                Console.WriteLine("Even number");
            else
                Console.WriteLine("Odd number");
        }
    }
}
